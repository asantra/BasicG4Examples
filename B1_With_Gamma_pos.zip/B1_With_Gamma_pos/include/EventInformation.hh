#ifndef B1EventInformation_h
#define B1EventInformation_h 1

#include "G4VUserEventInformation.hh"
#include "globals.hh"

namespace B1
{

class EventInformation : public G4VUserEventInformation
{
public:

    EventInformation() = default;
    ~EventInformation() override = default;

    void SetRootEntry(G4int id)
    {
        fRootEntry = id;
    }

    G4int GetRootEntry() const
    {
        return fRootEntry;
    }

    void Print() const override {}

private:

    G4int fRootEntry = -1;
};

}

#endif