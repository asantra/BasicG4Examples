//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
/// \file RunAction.cc
/// \brief Implementation of the B1::RunAction class

#include "RunAction.hh"

#include "DetectorConstruction.hh"
#include "PrimaryGeneratorAction.hh"

#include "G4AccumulableManager.hh"
#include "G4LogicalVolume.hh"
#include "G4ParticleDefinition.hh"
#include "G4ParticleGun.hh"
#include "G4Run.hh"
#include "G4RunManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"
#include "G4AnalysisManager.hh"
#include "G4ParticleTable.hh"

namespace B1
{

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

RunAction::RunAction()
{
  // add new units for dose
  //
  const G4double milligray = 1.e-3 * gray;
  const G4double microgray = 1.e-6 * gray;
  const G4double nanogray = 1.e-9 * gray;
  const G4double picogray = 1.e-12 * gray;

  new G4UnitDefinition("milligray", "milliGy", "Dose", milligray);
  new G4UnitDefinition("microgray", "microGy", "Dose", microgray);
  new G4UnitDefinition("nanogray", "nanoGy", "Dose", nanogray);
  new G4UnitDefinition("picogray", "picoGy", "Dose", picogray);

  // Register accumulable to the accumulable manager
  G4AccumulableManager* accumulableManager = G4AccumulableManager::Instance();
  accumulableManager->Register(fEdep);
  accumulableManager->Register(fEdep2);

  //accumulableManager->Register(fInteractingEvents);


  auto analysisManager = G4AnalysisManager::Instance();

  analysisManager->SetDefaultFileType("root");

  // Create directories
  // analysisManager->SetHistoDirectoryName("histograms");
  // analysisManager->SetNtupleDirectoryName("ntuple");
  analysisManager->SetVerboseLevel(1);
  analysisManager->SetNtupleMerging(true);
  // Note: merging ntuples is available only with Root output

  // Book histograms, ntuple
  //

  // Creating histograms
  analysisManager->CreateH1("Edep", "Edep in my detector", 50, 0., 1000* keV);
  // Creating ntuple
  //
  analysisManager->CreateNtuple("Energy", "Gamma Interactions");

  analysisManager->CreateNtupleIColumn("eventID");
  analysisManager->CreateNtupleIColumn("trackID");

  //analysisManager->CreateNtupleDColumn("Edep");
  //analysisManager->CreateNtupleIColumn("stepNo");
  analysisManager->CreateNtupleIColumn("pdgID");
  analysisManager->CreateNtupleIColumn("parentID");
  analysisManager->CreateNtupleDColumn("boundaryEnergy");
  analysisManager->CreateNtupleDColumn("x_pos");
  analysisManager->CreateNtupleDColumn("y_pos");
  analysisManager->CreateNtupleDColumn("z_pos");
  analysisManager->CreateNtupleDColumn("x_dir");
  analysisManager->CreateNtupleDColumn("y_dir");
  analysisManager->CreateNtupleDColumn("z_dir");


  //analysisManager->CreateNtupleDColumn("x");
  //analysisManager->CreateNtupleDColumn("y");
  //analysisManager->CreateNtupleDColumn("z");

  analysisManager->FinishNtuple();



  analysisManager->CreateNtuple("PDGEdep", "Energy deposited by particle type");
  analysisManager->CreateNtupleIColumn("eventID");
  //analysisManager->CreateNtupleIColumn("trackID");
  analysisManager->CreateNtupleIColumn("pdgID");
  analysisManager->CreateNtupleDColumn("totalEdep");
  //analysisManager->CreateNtupleIColumn("parentID");
  //analysisManager->CreateNtupleIColumn("trackID");

  //analysisManager->CreateNtupleIColumn("pdgID");

  analysisManager->FinishNtuple();


  analysisManager->CreateNtuple("TrackEdep","Energy deposited by track");
  analysisManager->CreateNtupleIColumn("eventID");
  analysisManager->CreateNtupleIColumn("trackID");
  analysisManager->CreateNtupleDColumn("totalEdep");
  analysisManager->CreateNtupleIColumn("pdgID");
  analysisManager->CreateNtupleIColumn("parentID");

  analysisManager->FinishNtuple();

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void RunAction::BeginOfRunAction(const G4Run*)
{
  // inform the runManager to save random number seed
  G4RunManager::GetRunManager()->SetRandomNumberStore(false);

  // reset accumulables to their initial values
  G4AccumulableManager* accumulableManager = G4AccumulableManager::Instance();
  accumulableManager->Reset();

  // Get analysis manager
  auto analysisManager = G4AnalysisManager::Instance();

  // Open an output file
  //
  //G4String fileName = "myEdep.root";
  // Other supported output types:
  // G4String fileName = "B4.csv";
  // G4String fileName = "B4.hdf5";
  // G4String fileName = "B4.xml";
  //analysisManager->Reset();
   // if (analysisManager->IsActive())
   // {
    // analysisManager->OpenFile();
   // }
  G4cout << "Using " << analysisManager->GetType() << G4endl;


}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void RunAction::EndOfRunAction(const G4Run* run)
{
  G4int nofEvents = run->GetNumberOfEvent();
  if (nofEvents == 0) return;

  // Merge accumulables
  G4AccumulableManager* accumulableManager = G4AccumulableManager::Instance();
  accumulableManager->Merge();

  // Compute dose = total energy deposit in a run and its variance
  //
  G4double edep = fEdep.GetValue();
  G4double edep2 = fEdep2.GetValue();

  //G4int interactingEvents = fInteractingEvents.GetValue();
  //G4int gammaEntries = fInteractingEvents.GetValue();

  G4double rms = edep2 - edep * edep / nofEvents;
  if (rms > 0.)
    rms = std::sqrt(rms);
  else
    rms = 0.;

  const auto detConstruction = static_cast<const DetectorConstruction*>(
    G4RunManager::GetRunManager()->GetUserDetectorConstruction());
  G4double mass = detConstruction->GetScoringVolume()->GetMass();
  /*
  for (auto vol : detConstruction->GetScoringVolume())
  {
    G4double mass = vol->GetMass();
  }
  */
  G4double dose = edep / mass;
  G4double rmsDose = rms / mass;

  // Run conditions
  //  note: There is no primary generator action object for "master"
  //        run manager for multi-threaded mode.
  const auto generatorAction = static_cast<const PrimaryGeneratorAction*>(
    G4RunManager::GetRunManager()->GetUserPrimaryGeneratorAction());
  G4String runCondition;
  if (generatorAction) {
    //const G4ParticleGun* particleGun = generatorAction->GetParticleGun();
    //runCondition += particleGun->GetParticleDefinition()->GetParticleName();
    //runCondition += " of ";
    //G4double particleEnergy = particleGun->GetParticleEnergy();
    //runCondition += G4BestUnit(particleEnergy, "Energy");

    const G4ParticleGun* gammaGun = generatorAction->GetGammaGun();
    //const G4ParticleGun* neutronGun = generatorAction->GetNeutronGun();

    runCondition += gammaGun->GetParticleDefinition()->GetParticleName();
    runCondition += " (";
    runCondition += G4BestUnit(gammaGun->GetParticleEnergy(),"Energy");
    runCondition += ") + ";

    //runCondition += neutronGun->GetParticleDefinition()->GetParticleName();
    //runCondition += " (";
    //runCondition += G4BestUnit(neutronGun->GetParticleEnergy(),"Energy");
    //runCondition += ")";
  //auto analysisManager = G4AnalysisManager::Instance();
  // save histograms & ntuple
  //
   // if (analysisManager->IsActive())
   // {
    // analysisManager->Write();
    // analysisManager->CloseFile();
   // }


  }
  auto analysisManager = G4AnalysisManager::Instance();
  analysisManager->Write();
  analysisManager->CloseFile();




  // Print
  //
  if (IsMaster()) {
    G4cout << G4endl << "--------------------End of Global Run-----------------------";
  }
  else {
    G4cout << G4endl << "--------------------End of Local Run------------------------";
  }

  G4cout << G4endl << " The run is " << nofEvents << " " << runCondition << G4endl << G4endl;
  //G4cout << "  --> cumulated edep per run in scoring volume = " << G4BestUnit(edep, "Energy")
        // << " = " << edep/joule << " joule" << G4endl;
  G4cout << "  --> mass of scoring volume = " << G4BestUnit(mass, "Mass") << G4endl << G4endl; 
  G4cout << " Absorbed dose per run in scoring volume = edep/mass = " << G4BestUnit(dose, "Dose")
         << "; rms = " << G4BestUnit(rmsDose, "Dose") << G4endl;
  G4cout<<"------------------------------------------------------------" << G4endl << G4endl;


}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void RunAction::AddEdep(G4double edep)
{
  fEdep += edep;
  fEdep2 += edep * edep;
}
/*
void RunAction::CountInteractingEvent()
{
  fInteractingEvents +=1;
}
*/
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

}  // namespace B1
